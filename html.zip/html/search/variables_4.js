var searchData=
[
  ['plazas_5flibres_118',['plazas_libres',['../classEstaciones.html#a9af687b225bf0333e16874ad92ff3145',1,'Estaciones']]]
];
