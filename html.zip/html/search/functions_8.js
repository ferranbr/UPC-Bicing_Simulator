var searchData=
[
  ['nueva_5fbici_100',['nueva_bici',['../classBicicletas.html#a74bae7538145a6caa3a5d9141e5ff71d',1,'Bicicletas']]],
  ['nueva_5fubi_101',['nueva_ubi',['../classBicicletas.html#af2cbf2d917010949a6a2197eb9910410',1,'Bicicletas']]],
  ['nuevo_5fviaje_102',['nuevo_viaje',['../classBicicleta.html#a15b734910abf7c91067771daf7f4da7f',1,'Bicicleta']]]
];
